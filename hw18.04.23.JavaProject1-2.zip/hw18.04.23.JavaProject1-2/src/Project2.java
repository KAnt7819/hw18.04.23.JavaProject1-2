public class Project2 {
   //Практика алгоритмов
   //На выбор: либо реализовать любую из сортировок самостоятельно, либо решить задание ниже.
   //Задание из собеседования Яндекс: дана строка вида AAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
   // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.

    public static String compressString(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }

        StringBuilder sb = new StringBuilder();
        char currentChar = str.charAt(0);
        int currentCharCount = 1;

        for (int i = 1; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c == currentChar) {
                currentCharCount++;
            } else {
                sb.append(currentChar);
                if (currentCharCount > 1) {
                    sb.append(currentCharCount);
                }
                currentChar = c;
                currentCharCount = 1;
            }
        }
        sb.append(currentChar);
        if (currentCharCount > 1) {
            sb.append(currentCharCount);
        }

        return sb.toString();
    }


    public static void main(String[] args) {
        String str = "AAABBBCCCDDEG";
        String compressedStr = compressString(str);
        System.out.println(compressedStr);

    }
}