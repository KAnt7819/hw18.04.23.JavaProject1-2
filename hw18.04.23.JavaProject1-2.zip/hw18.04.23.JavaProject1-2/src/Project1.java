import java.util.Arrays;
import java.util.Scanner;

public class Project1 {
    //Проект 1. Двумерные массивы
    //1 Создайте двумерный массив и заполните его буквами русского алфавита.

    public static void main(String[] args) {

//1. Двумерные массивы
        //1 Создайте двумерный массив и заполните его буквами русского алфавита.
        char [][] alphabet = new char[5][7];
        char first = 'А';
        char last = 'Я';
        for (int i = 0; i < alphabet.length; i++) {
            for (int j = 0; j < alphabet[i].length; j++) {
                alphabet[i][j]= first; first++;
                if (first>last){
                    break;
                }
            }
        }
        System.out.println(Arrays.deepToString(alphabet));
        System.out.println();


    }
}